//import { ChartStyle } from './chartstyle'
import { Chart } from 'react-charts'


const Charts = () => {
    return (
        <Chart/>
    )
}

export default Charts