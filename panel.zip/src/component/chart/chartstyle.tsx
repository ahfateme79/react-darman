import styled from 'styled-components'

export const ChartStyle =styled.div`
    width: 90%;
`