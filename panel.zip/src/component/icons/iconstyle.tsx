import styled from 'styled-components'

export const Icons =styled.i`
    font-size: 30px;
    color: #000000;
`