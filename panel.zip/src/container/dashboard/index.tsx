import Main from '../../component/main/main'


const Dashboard=()=>{
    return(
        <Main/>
    )
}
export default Dashboard