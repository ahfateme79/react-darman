import { METHODS } from 'http'
import { FormStyle, Filedset, InputStyle, Textarea } from './formstyle'

interface FormProps {
    input: { placeholder: string; type: string; name: string }[] | undefined
    handlesubmit: (event: React.FormEvent<HTMLFormElement>) => void
    handlechange: (event: React.ChangeEvent<HTMLInputElement>) => void
}

const Form: React.FC<FormProps> = ({ input, handlesubmit, handlechange }) => {


    return (
        <>
            <FormStyle onSubmit={handlesubmit}>
                <Filedset>
                    {
                        input?.map(n => {
                            return (
                                n.type === 'textarea' ?

                                    <Textarea placeholder={n.placeholder}></Textarea>
                                    : <InputStyle placeholder={n.placeholder} type={n.type} onChange={handlechange}></InputStyle>
                            )
                        })
                    }
                </Filedset>
                <button>submit</button>
            </FormStyle>
        </>
    )
}
export default Form