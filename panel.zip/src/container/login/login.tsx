import LoginForm from "./loginform"

const Login=()=>{
    return(
        <LoginForm/>
    )
}
export default Login