const Routes = [
    { name: "index", path: "/", containerpath: "/containers/dashboard/index" },
    { name: "index", path: "/carts", containerpath: "/containers/carts/index" },
    { name: "index", path: "/products", containerpath: "/containers/products/index" },
    { name: "index", path: "/users", containerpath: "/containers/users/users" },
    { name: "index", path: "/setting", containerpath: "/containers/setting/index" },
    { name: "index", path: "/login", containerpath: "/containers/login/index" }
]

export default Routes